package com.example.calculadora

import android.content.Intent
import android.icu.number.IntegerWidth
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    private lateinit var etNumero1: EditText
    private lateinit var txtResultado: TextView
    private lateinit var btnSumar: Button
    private lateinit var etNumero2: EditText
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        setupUI()
        Log.i("MainActivity", "onCreate")


    }

    private fun setupUI() {
        etNumero1 = findViewById(R.id.etNumero1)
        etNumero2 = findViewById(R.id.etNumero2)
        btnSumar = findViewById(R.id.btnSumar)


        btnSumar.setOnClickListener {
            //realizar accion
            realizarSuma()
        }
    }

    private fun realizarSuma() {
        val numero1=etNumero1.text.toString().toInt()
        val numero2=etNumero2.text.toString().toInt()
        val resultadoSuma:Int = sumar(numero1, numero2)

        Log.i(TAG, "El numero 1  es $numero1 y el numero2 es $numero2")
        LanzarResultadoActivity(resultadoSuma)

    }

    private fun LanzarResultadoActivity(resultadoSuma: Int) {
        val intent = Intent(this, ResultadoActivity::class.java)
        intent.putExtra("RESULTADO", resultadoSuma)
        startActivity(intent)
    }

    private fun sumar(numero1: Int, numero2: Int): Int {

        return numero1+numero2
    }

    override fun onStart() {
        super.onStart()
        Log.i(TAG, "onStart")
    }

    override fun onResume() {
        super.onResume()
        Log.i(TAG, "onResume")
    }

    override fun onPause() {
        super.onPause()
        Log.i(TAG, "onPause")
    }

    override fun onStop() {
        super.onStop()
        Log.i(TAG, "onStop")
    }

    override fun onDestroy() {
        Log.i(TAG, "onDestroy")
        super.onDestroy()
    }
    private val TAG = "MainActivity"

}