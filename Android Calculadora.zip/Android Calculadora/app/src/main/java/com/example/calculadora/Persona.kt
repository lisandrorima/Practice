package com.example.calculadora

class Persona(var nombre:String, var apellido:String, var genero: String="") {



}